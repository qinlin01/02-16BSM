/**
 * Created by wangdao on 2016/8/1.
 */
angular.module("lrApp")
  .directive("lrSearch", function() {
    return {
      restrict: 'A',
      scope: {},

    }
  });