/**
 * Created by wangdao on 2016/8/30.
 */
// 部署项目后台访问地址
var serverApi = "http://localhost:8099/";

// 前台访问地址
var htdocs = "" ;

var previewPath = "";

// 控制中英文
/**
 * 空： 可配置中英文
 *  1： 不可配置，系统为中文
 *  2： 不可配置，系统为英文
 * @type {number}
 */
var sysLanguage = '1';