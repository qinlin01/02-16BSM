// 初始化下拉数据
var getAlertMsg = function () {
    return {

        EDIT_SELECT_MSG:"请选择一条数据进行修改",
        DELETE_SELECT_MSG:"请选择单据进行删除",
        VIEW_SELECT_MSG:"请选择一条单据进行查看",
        DELETE_ONE_SELECT_MSG:"请选择一条单据进行删除",
        CHECK_ONE_SELECT_MSG:"请选择一条单据进行审核",
        UNPASS_ONE_SELECT_MSG:"请选择一条数据进行驳回",
        DELETE:"删除",
        BACK:"返回",
        CANCEL_DELETE:"取消删除",
        IF_DELETE:"是否删除",
        DELETE_SUC:"删除成功",
        DELETE_ONCE:"该数据不能删除，请选择状态为暂存的数据进行删除",
        SUBMIT_SUC:"提交成功",
        WAIT_CHECK:"等待审核",
        PASS:"通过",
        UN_PUSS:"不通过",
        UN_PASS_CHECK:"审核未通过",
        CHECK_PASS:"审核通过",
        REVOKE_SELECT_MSG:"请选择一条单据进行撤销",


/*
        EDIT_SELECT_MSG:"请选择一条数据进行cha",
        EDIT_SELECT_MSG:"请选择一条数据进行修改",
        EDIT_SELECT_MSG:"请选择一条数据进行修改",*/


        VERIFY_CHECK_MSG:"请先填写所有的必输项"


    };

};

